package br.ufmt.poo.fitMe.service;

import br.ufmt.poo.fitMe.ui.dto.UsuarioDTO;


public interface UsuarioService {
    
    public void registrar(UsuarioDTO dto);
    
    public UsuarioDTO login(String email, String senha);
}
