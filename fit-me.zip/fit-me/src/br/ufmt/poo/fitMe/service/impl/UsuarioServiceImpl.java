package br.ufmt.poo.fitMe.service.impl;

import br.ufmt.poo.fitMe.persistencia.UsuarioPersistencia;
import br.ufmt.poo.fitMe.persistencia.entidade.Usuario;
import br.ufmt.poo.fitMe.persistencia.impl.UsuarioPersistenciaImpl;
import br.ufmt.poo.fitMe.service.UsuarioService;
import br.ufmt.poo.fitMe.ui.dto.UsuarioDTO;
import java.util.ArrayList;
import java.util.List;

public class UsuarioServiceImpl implements UsuarioService{

    @Override
    public void registrar(UsuarioDTO dto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public UsuarioDTO login(String email, String senha) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
