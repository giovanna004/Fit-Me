package br.ufmt.poo.fitMe.persistencia;

import br.ufmt.poo.fitMe.persistencia.entidade.Usuario;
import java.util.List;

public interface UsuarioPersistencia {
    
    public void cadastrar(Usuario usuario);
    
    public void entrar(String email, String senha);
    
    public List<Usuario> buscar();
}
