package br.ufmt.poo.fitMe.persistencia.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;
import java.sql.ResultSet;

public class ConexaoPostgreSQL {
    private static final String URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String USUARIO = "postgres";
    private static final String SENHA = "123456";

    public static Connection conectar() throws SQLException {
        Connection con = DriverManager.getConnection(URL, USUARIO, SENHA);
        return con;
    }
           
    public void fecharConexao(){
        
    }
    
    public void executar (String sql, List parametros) {
        
        try {
            Connection con = conectar();
            PreparedStatement pstmt = con.prepareStatement(sql);
            for (int i = 0; i < parametros.size(); i++) {
                pstmt.setObject(i + 1, parametros.get(i));
            }
            pstmt.execute();
            
            fecharConexao();
        } catch (SQLException erro) {
            erro.printStackTrace();
            throw new RuntimeException("Erro ao inserir/atualizar no banco de dados!");
        }
    }
    
    public ResultSet executarQuery (String sql) {
        
        try {
            Connection con = conectar();
            return con.createStatement().executeQuery(sql);
        } catch (SQLException erro) {
            erro.printStackTrace();
            throw new RuntimeException("Erro ao consultar no banco de dados!");
        }
    }
}
