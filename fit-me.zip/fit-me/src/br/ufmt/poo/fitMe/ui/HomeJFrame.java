package br.ufmt.poo.fitMe.ui;

import br.ufmt.poo.fitMe.Drawer.MeuDrawerBuilder;
import javax.swing.*;
import java.awt.*;
import raven.drawer.Drawer;
import raven.popup.GlassPanePopup;

public class HomeJFrame extends javax.swing.JFrame {
    
    public HomeJFrame() {
        GlassPanePopup.install(this);
        MeuDrawerBuilder meuDrawerBuilder = new MeuDrawerBuilder();
        Drawer.getInstance().setDrawerBuilder(meuDrawerBuilder);
        setTitle("Home");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 550));
        setLocationRelativeTo(null);
        
        initComponents();
        
        
        addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowOpened(java.awt.event.WindowEvent evt) {
            
        }
    });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        botaoRegistro = new javax.swing.JButton();
        botaoLogIn = new javax.swing.JButton();
        botaoMenu = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        botaoRegistro.setBackground(new java.awt.Color(153, 153, 153));
        botaoRegistro.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        botaoRegistro.setForeground(new java.awt.Color(255, 255, 255));
        botaoRegistro.setText("Registrar");
        botaoRegistro.setBorderPainted(false);
        botaoRegistro.setPreferredSize(new java.awt.Dimension(0, 50));
        botaoRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoRegistroActionPerformed(evt);
            }
        });

        botaoLogIn.setBackground(new java.awt.Color(41, 167, 217));
        botaoLogIn.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        botaoLogIn.setForeground(new java.awt.Color(255, 255, 255));
        botaoLogIn.setText("Login");
        botaoLogIn.setBorderPainted(false);
        botaoLogIn.setPreferredSize(new java.awt.Dimension(0, 50));
        botaoLogIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoLogInActionPerformed(evt);
            }
        });

        botaoMenu.setBackground(new java.awt.Color(204, 204, 204));
        botaoMenu.setForeground(new java.awt.Color(255, 255, 255));
        botaoMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoMenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(botaoMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(319, 319, 319)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(botaoLogIn, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE)
                    .addComponent(botaoRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(246, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(botaoMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(138, 138, 138)
                .addComponent(botaoLogIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botaoRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(226, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void botaoRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoRegistroActionPerformed
        botaoRegistro.setBackground(new Color(41,167,217));
        botaoLogIn.setBackground(new Color(153,153,153));

        
    }//GEN-LAST:event_botaoRegistroActionPerformed

    private void botaoLogInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoLogInActionPerformed
        botaoLogIn.setBackground(new Color(41,167,217));
        botaoRegistro.setBackground(new Color(153,153,153));

       
    }//GEN-LAST:event_botaoLogInActionPerformed

    private void botaoMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoMenuActionPerformed
        Drawer.getInstance().showDrawer();
    }//GEN-LAST:event_botaoMenuActionPerformed


        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoLogIn;
    private javax.swing.JButton botaoMenu;
    private javax.swing.JButton botaoRegistro;
    // End of variables declaration//GEN-END:variables
}
