package br.ufmt.poo.fitMe.ui;

import javax.swing.*;
import java.awt.*;

public class HomeJFrame extends javax.swing.JFrame {
    
    private LoginPessoaJPanel login;
    private RegistroJPanel registro;
    
    public void setLogin() {
        if (login == null) {
            login = new LoginPessoaJPanel();
        }
        jPanel2.removeAll();
        jPanel2.add(login);
        SwingUtilities.updateComponentTreeUI(jPanel2);
    }

    public void setRegistro() {
        if (registro == null) {
            registro = new RegistroJPanel();
        }
        jPanel2.removeAll();
        jPanel2.add(registro);
        SwingUtilities.updateComponentTreeUI(jPanel2);
    }

   
    public HomeJFrame() {
        setTitle("Home");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 550));
        setLocationRelativeTo(null);
        
        initComponents();
        
        addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowOpened(java.awt.event.WindowEvent evt) {
            setLogin();
        }
    });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        bemVindoLabel = new javax.swing.JLabel();
        botaoLogIn = new javax.swing.JButton();
        botaoRegistro = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setFocusable(false);
        jPanel2.setMinimumSize(new java.awt.Dimension(720, 840));
        jPanel2.setName(""); // NOI18N
        jPanel2.setPreferredSize(new java.awt.Dimension(720, 920));
        jPanel2.setRequestFocusEnabled(false);
        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setFocusable(false);
        jPanel1.setPreferredSize(new java.awt.Dimension(256, 904));

        bemVindoLabel.setBackground(new java.awt.Color(153, 153, 153));
        bemVindoLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        bemVindoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bemVindoLabel.setText("Bem-Vindo(a)");
        bemVindoLabel.setFocusable(false);
        bemVindoLabel.setOpaque(true);

        botaoLogIn.setBackground(new java.awt.Color(41, 167, 217));
        botaoLogIn.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        botaoLogIn.setForeground(new java.awt.Color(255, 255, 255));
        botaoLogIn.setText("Login");
        botaoLogIn.setBorderPainted(false);
        botaoLogIn.setPreferredSize(new java.awt.Dimension(0, 50));
        botaoLogIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoLogInActionPerformed(evt);
            }
        });

        botaoRegistro.setBackground(new java.awt.Color(153, 153, 153));
        botaoRegistro.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        botaoRegistro.setForeground(new java.awt.Color(255, 255, 255));
        botaoRegistro.setText("Registrar");
        botaoRegistro.setBorderPainted(false);
        botaoRegistro.setPreferredSize(new java.awt.Dimension(0, 50));
        botaoRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoRegistroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bemVindoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botaoLogIn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botaoRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE))
                .addGap(35, 35, 35))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(bemVindoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(107, 107, 107)
                .addComponent(botaoLogIn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botaoRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1035, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1035, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botaoLogInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoLogInActionPerformed
        botaoLogIn.setBackground(new Color(41,167,217));
        botaoRegistro.setBackground(new Color(153,153,153));

        setLogin();
    }//GEN-LAST:event_botaoLogInActionPerformed

    private void botaoRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoRegistroActionPerformed
        botaoRegistro.setBackground(new Color(41,167,217));
        botaoLogIn.setBackground(new Color(153,153,153));

        setRegistro();
    }//GEN-LAST:event_botaoRegistroActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bemVindoLabel;
    private javax.swing.JButton botaoLogIn;
    private javax.swing.JButton botaoRegistro;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
