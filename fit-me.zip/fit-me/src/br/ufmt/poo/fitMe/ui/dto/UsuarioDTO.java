package br.ufmt.poo.fitMe.ui.dto;

public class UsuarioDTO {
    private String nome;
    private String email;
    private String data_nasc;
    private String senha;
    
}


