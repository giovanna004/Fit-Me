package br.ufmt.poo.fitMe.ui;

public class RegistroJPanel extends javax.swing.JPanel {

   
    public RegistroJPanel() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        registro = new javax.swing.JLabel();
        nome = new javax.swing.JLabel();
        nomeField = new javax.swing.JTextField();
        email = new javax.swing.JLabel();
        emailField = new javax.swing.JTextField();
        dataNascimento = new javax.swing.JLabel();
        dataNascimentoField = new javax.swing.JFormattedTextField();
        senha = new javax.swing.JLabel();
        senhaField = new javax.swing.JPasswordField();
        confirmarSenha = new javax.swing.JLabel();
        confirmarSenhaField = new javax.swing.JPasswordField();
        sexo = new javax.swing.JLabel();
        radioButtonFeminino = new javax.swing.JRadioButton();
        radioButtonMasculino = new javax.swing.JRadioButton();
        radioButtonPND = new javax.swing.JRadioButton();
        botaoRegistrar = new javax.swing.JButton();
        botaoJaTenhoConta = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setName("JPanel"); // NOI18N
        setPreferredSize(new java.awt.Dimension(720, 904));

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(720, 840));
        jScrollPane1.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                jScrollPane1MouseWheelMoved(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        registro.setBackground(new java.awt.Color(40, 40, 40));
        registro.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        registro.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        registro.setText("Registro Usuário");
        registro.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        registro.setMaximumSize(new java.awt.Dimension(420, 50));
        registro.setMinimumSize(new java.awt.Dimension(420, 32));
        registro.setPreferredSize(new java.awt.Dimension(420, 50));

        nome.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        nome.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        nome.setText("Nome");

        nomeField.setBackground(new java.awt.Color(204, 204, 204));
        nomeField.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        nomeField.setMaximumSize(new java.awt.Dimension(420, 50));
        nomeField.setMinimumSize(new java.awt.Dimension(420, 50));
        nomeField.setPreferredSize(new java.awt.Dimension(420, 50));
        nomeField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeFieldActionPerformed(evt);
            }
        });

        email.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        email.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        email.setText("Email");

        emailField.setBackground(new java.awt.Color(204, 204, 204));
        emailField.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        emailField.setMaximumSize(new java.awt.Dimension(420, 50));
        emailField.setMinimumSize(new java.awt.Dimension(420, 50));
        emailField.setPreferredSize(new java.awt.Dimension(420, 50));
        emailField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailFieldActionPerformed(evt);
            }
        });

        dataNascimento.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        dataNascimento.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        dataNascimento.setText("Data de Nascimento");

        dataNascimentoField.setBackground(new java.awt.Color(204, 204, 204));
        dataNascimentoField.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter()));
        dataNascimentoField.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        dataNascimentoField.setMaximumSize(new java.awt.Dimension(420, 50));
        dataNascimentoField.setMinimumSize(new java.awt.Dimension(420, 50));
        dataNascimentoField.setPreferredSize(new java.awt.Dimension(420, 50));
        dataNascimentoField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dataNascimentoFieldActionPerformed(evt);
            }
        });

        senha.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        senha.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        senha.setText("Senha");

        senhaField.setBackground(new java.awt.Color(204, 204, 204));
        senhaField.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        senhaField.setMaximumSize(new java.awt.Dimension(420, 50));
        senhaField.setMinimumSize(new java.awt.Dimension(420, 50));
        senhaField.setPreferredSize(new java.awt.Dimension(420, 50));
        senhaField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                senhaFieldActionPerformed(evt);
            }
        });

        confirmarSenha.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        confirmarSenha.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        confirmarSenha.setText("Confirmar Senha");

        confirmarSenhaField.setBackground(new java.awt.Color(204, 204, 204));
        confirmarSenhaField.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        confirmarSenhaField.setMaximumSize(new java.awt.Dimension(420, 50));
        confirmarSenhaField.setMinimumSize(new java.awt.Dimension(420, 50));
        confirmarSenhaField.setPreferredSize(new java.awt.Dimension(420, 50));

        sexo.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        sexo.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        sexo.setText("Sexo");

        buttonGroup1.add(radioButtonFeminino);
        radioButtonFeminino.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        radioButtonFeminino.setSelected(true);
        radioButtonFeminino.setText("Femino");
        radioButtonFeminino.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        radioButtonFeminino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioButtonFemininoActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioButtonMasculino);
        radioButtonMasculino.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        radioButtonMasculino.setText("Masculino");
        radioButtonMasculino.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        radioButtonMasculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioButtonMasculinoActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioButtonPND);
        radioButtonPND.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        radioButtonPND.setText("Prefiro não informar");
        radioButtonPND.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        radioButtonPND.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioButtonPNDActionPerformed(evt);
            }
        });

        botaoRegistrar.setBackground(new java.awt.Color(242, 94, 107));
        botaoRegistrar.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        botaoRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        botaoRegistrar.setText("Registrar");
        botaoRegistrar.setBorderPainted(false);
        botaoRegistrar.setMaximumSize(new java.awt.Dimension(420, 50));
        botaoRegistrar.setMinimumSize(new java.awt.Dimension(420, 50));
        botaoRegistrar.setPreferredSize(new java.awt.Dimension(420, 50));
        botaoRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoRegistrarActionPerformed(evt);
            }
        });

        botaoJaTenhoConta.setBackground(new java.awt.Color(204, 204, 204));
        botaoJaTenhoConta.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        botaoJaTenhoConta.setText("Já possuo uma conta");
        botaoJaTenhoConta.setBorderPainted(false);
        botaoJaTenhoConta.setMaximumSize(new java.awt.Dimension(420, 50));
        botaoJaTenhoConta.setMinimumSize(new java.awt.Dimension(420, 50));
        botaoJaTenhoConta.setPreferredSize(new java.awt.Dimension(420, 50));
        botaoJaTenhoConta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoJaTenhoContaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(150, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(botaoJaTenhoConta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sexo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(confirmarSenha, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(senha, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(email, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dataNascimento, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(nome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(registro, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(radioButtonFeminino)
                                .addGap(12, 12, 12)
                                .addComponent(radioButtonMasculino, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(radioButtonPND, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(botaoRegistrar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(confirmarSenhaField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(senhaField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dataNascimentoField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(emailField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nomeField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(150, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(registro, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nomeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(emailField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dataNascimentoField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(senha, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(senhaField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(confirmarSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(confirmarSenhaField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(sexo, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(radioButtonFeminino)
                    .addComponent(radioButtonMasculino)
                    .addComponent(radioButtonPND))
                .addGap(18, 18, 18)
                .addComponent(botaoRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botaoJaTenhoConta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);
        jPanel1.getAccessibleContext().setAccessibleName("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 904, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
    
    private void dataNascimentoFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dataNascimentoFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dataNascimentoFieldActionPerformed

    private void nomeFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeFieldActionPerformed

    private void emailFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailFieldActionPerformed

    private void senhaFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_senhaFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_senhaFieldActionPerformed

    private void radioButtonFemininoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioButtonFemininoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radioButtonFemininoActionPerformed

    private void radioButtonMasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioButtonMasculinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radioButtonMasculinoActionPerformed

    private void radioButtonPNDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioButtonPNDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radioButtonPNDActionPerformed

    private void botaoRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoRegistrarActionPerformed
       
    }//GEN-LAST:event_botaoRegistrarActionPerformed

    private void botaoJaTenhoContaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoJaTenhoContaActionPerformed
	nomeField.setText("");
        emailField.setText("");
        senhaField.setText("");
	dataNascimentoField.setValue(null);
        
    }//GEN-LAST:event_botaoJaTenhoContaActionPerformed

    private void jScrollPane1MouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_jScrollPane1MouseWheelMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_jScrollPane1MouseWheelMoved


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoJaTenhoConta;
    private javax.swing.JButton botaoRegistrar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel confirmarSenha;
    private javax.swing.JPasswordField confirmarSenhaField;
    private javax.swing.JLabel dataNascimento;
    private javax.swing.JFormattedTextField dataNascimentoField;
    private javax.swing.JLabel email;
    private javax.swing.JTextField emailField;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel nome;
    private javax.swing.JTextField nomeField;
    private javax.swing.JRadioButton radioButtonFeminino;
    private javax.swing.JRadioButton radioButtonMasculino;
    private javax.swing.JRadioButton radioButtonPND;
    private javax.swing.JLabel registro;
    private javax.swing.JLabel senha;
    private javax.swing.JPasswordField senhaField;
    private javax.swing.JLabel sexo;
    // End of variables declaration//GEN-END:variables
}
