
package br.ufmt.poo.fitMe.Drawer;
import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.extras.FlatSVGIcon;
import java.awt.Color;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import raven.drawer.component.DrawerPanel;
import raven.drawer.component.SimpleDrawerBuilder;
import raven.drawer.component.footer.SimpleFooterData;
import raven.drawer.component.header.SimpleHeaderData;
import raven.drawer.component.header.SimpleHeaderStyle;
import raven.drawer.component.menu.MenuAction;
import raven.drawer.component.menu.MenuEvent;
import raven.drawer.component.menu.MenuValidation;
import raven.drawer.component.menu.SimpleMenuOption;
import raven.drawer.component.menu.SimpleMenuStyle;
import raven.drawer.component.menu.data.Item;
import raven.drawer.component.menu.data.MenuItem;
import raven.swing.AvatarIcon;


public class MeuDrawerBuilder extends SimpleDrawerBuilder {

    @Override
    public SimpleHeaderData getSimpleHeaderData() {
        return new SimpleHeaderData()
                .setIcon(new AvatarIcon(getClass().getResource("/Imagens/Icon1.png"), 60, 60, 999))
                .setTitle("Usuário")
                .setDescription("user@gmail.com");
    }

    @Override
    public SimpleMenuOption getSimpleMenuOption() {

        MenuItem[] items = new MenuItem[] {
            new Item.Label("MAIN"),
            new Item("Dashboard", "icons/dashboard.svg"),
            new Item("Treinos", "icons/fitness-watch.svg")
                .subMenu("Superior")
                .subMenu("Inferior")
                .subMenu("Cardio"),
            new Item("Dietas", "icons/diet.svg")
                .subMenu("Segunda")
                .subMenu("Quarta")
                .subMenu("Sexta")
        };

        SimpleMenuOption simpleMenuOption = new SimpleMenuOption() {
            @Override
            public Icon buildMenuIcon(String path, float scale) {
                FlatSVGIcon icon = new FlatSVGIcon(path, 0.8f);
                FlatSVGIcon.ColorFilter colorFilter = new FlatSVGIcon.ColorFilter();
                colorFilter.add(Color.decode("#969696"), Color.decode("#FAFAFA"), Color.decode("#969696"));
                icon.setColorFilter(colorFilter);
                return icon;
            }
        };

        return simpleMenuOption
                .setMenus(items)
                .setMenuValidation(new MenuValidation() {
                    public boolean menuValidation(int index, int subIndex) {
                        if (index == 0) {
                            return false;
                        } else if (index == 3) {
                            return false;
                        }
                        return true;
                    }
                });
                
}

    @Override
    public SimpleFooterData getSimpleFooterData() {
        return new SimpleFooterData()
                .setTitle("FitMe - Treino e Dieta")
                .setDescription("Version 1.0.0");
    }
}
