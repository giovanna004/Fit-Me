package main;

import br.ufmt.poo.fitMe.ui.HomeJFrame;
import br.ufmt.poo.fitMe.ui.LoginERegistroJFrame;
import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.fonts.roboto.FlatRobotoFont;
import java.awt.Font;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main {
    public static void main(String[] args) {
        FlatRobotoFont.install();
        FlatLaf.registerCustomDefaultsSource("Libraries");
        UIManager.put("defaultFont", new Font (FlatRobotoFont.FAMILY, Font.PLAIN, 13));
        FlatLightLaf.setup();

        SwingUtilities.invokeLater(() -> {
            new LoginERegistroJFrame().setVisible(true);
        });
    }
}